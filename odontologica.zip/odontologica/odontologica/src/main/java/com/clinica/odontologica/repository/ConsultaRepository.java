package com.clinica.odontologica.repository;

public class ConsultaRepository {

    
}