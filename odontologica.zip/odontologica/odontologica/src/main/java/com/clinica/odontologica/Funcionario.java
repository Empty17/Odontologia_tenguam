package com.clinica.odontologica;

import java.time.LocalDate;

public class Funcionario {
    private String cpf;
    private String nome;
    private String email;
    private String senha;
    private String endereco;
    private LocalDate dataNascimento;
    private String telefone;
    private LocalDate dataAdmissao;
    private String cargo;
    private String especialidade; 
}
