package com.clinica.odontologica;

public class Usuario {
  private String cpfUsuario;
  private String nome;
  private String email;
  private String senha;
  private String dataNascimento;
  private String telefone;


}
