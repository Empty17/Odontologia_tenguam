package com.clinica.odontologica.service;

public class AgendamentoService {
    
}
